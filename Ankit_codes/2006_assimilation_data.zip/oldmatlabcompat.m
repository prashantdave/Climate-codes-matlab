clc
clear all
assim_dec =xlsread('assim_dec.xlsx');
save('assim_dec.mat', 'assim_dec', '-v7.3');
