clc
clear all
load('aod_mm_nov06.mat')
save('aod_mm_nov06.mat', '-v7.3')